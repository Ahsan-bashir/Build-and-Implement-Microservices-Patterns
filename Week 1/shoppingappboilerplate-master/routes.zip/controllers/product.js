const User = require('../model/user')
//const Product = require('../model/product')

const getProducts = async (req, res) => {
    
    // Write the code to get the product details

}

const addProduct = async (req, res) => {
    
    // Write the code to add the product details
}

const deleteProduct = async (req, res) => {
    
    // Write the code to delete the product details

}

module.exports = { getProducts, addProduct, deleteProduct };