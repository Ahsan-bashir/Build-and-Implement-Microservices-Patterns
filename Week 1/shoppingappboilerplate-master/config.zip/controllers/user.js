const User = require('../model/user')

const addUser = async (req, res) => {
    // Write the code to add the user
    try {
        const user = new User(req.body);
        console.log("---------not savees---------");
        await user.save();
        console.log("--------- savees---------");
        res.status(201).send(user);
    } catch (error) {
        res.status(400).send(error);
    }

}

module.exports = addUser;