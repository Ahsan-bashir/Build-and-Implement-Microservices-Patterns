const User = require('../model/user')


const getMovies = async (req, res) => {

    /**
        Write the code to get the movie details from database
    */


}

const addMovie = async (req, res) => {

    /**
        Write the code to add the movie details to the database
    */
}

const deleteMovie = async (req, res) => {

    /**
        Write the code to delete the movie details from database
    */

}

module.exports = { getMovies, addMovie, deleteMovie };