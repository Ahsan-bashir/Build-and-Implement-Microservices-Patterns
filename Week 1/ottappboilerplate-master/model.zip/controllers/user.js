const User = require('../model/user')

const addUser = async (req, res) => {

    /**
        Write the code to add the user details to the database
    */
    try {
        const user = new User(req.body)
        await user.save()
        res.status(201).send(user)
    } catch (e) {
        res.status.send(e)
    }
}


module.exports = addUser;